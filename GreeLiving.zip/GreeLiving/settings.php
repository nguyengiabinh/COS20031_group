<?php
//the school mariadb just cannot respond in time to establish a connection 
//after 14/11 or somewhere after 14/11 but definitely before 19/11/2023

// $host = "feenix-mariadb-web.swin.edu.au";
// $user = "s104219428";
// $pwd = "Lickmya@707";
// $sql_db = "s104219428_db";


//local mysql server of Binh
$host = "localhost";
$user = "root";
$pwd = "";
$sql_db = "s104219428_db2";
?>