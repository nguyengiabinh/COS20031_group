<?php
$servername = "feenix-mariadb.swin.edu.au";
$username = "s104191076";
$password = "100604";
$dbname = "s104191076_db";
?> 